#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortArray(vector<long> nums)
{

}

//=====================================================================================
vector<long> QuickSortList(vector<long> nums)
{

}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{

}

//=====================================================================================
vector<long> BucketSort(vector<long> nums, int max)
{

}

#endif

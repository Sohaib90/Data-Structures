#ifndef __BST_CPP
#define __BST_CPP
#include <iostream>
#include "bst.h"
#include <cstdlib>
#include <fstream>
#include <vector>
#include "time.h"
using namespace std;
template <class T>
bst<T>::bst()
{
}

template <class T>
void bst<T>::insert(string val,T key1)
{
}
template <class T>
bst_node<T>* bst<T>::search(T key1)
{
}

template <class T>
void bst<T>::delete_node(T key1)
{
}

template <class T>
int bst<T>::height( bst_node<T> *temp)
{
}

template<class T>
void bst<T>::replace(T old_key,T new_key)
{
}

template <class T>
bst_node<T>* bst<T>::getroot()
{
}
#endif

#ifndef __TREE_CPP
#define __LIST_CPP
#include "tree.h"
#include <fstream>

Tree::Tree()
{
}

Tree::Tree(string file)
{
}
Tree::~Tree()
{
}

void Tree::insert(string item)
{
}

vector<string> Tree::Locate(string qry)
{
}

string Tree::LComAc(string a, string b)
{
}

TreeItem* Tree::getHead()
{
	return head;
}

int Tree::countFiles()
{
}

#endif
